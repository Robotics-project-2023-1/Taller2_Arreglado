import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String #Tipo de mensaje recibido en el topico robot_bot_teclas
import serial
import time
ser = serial.Serial("/dev/ttyACM0", baudrate=115200) #Modificar el puerto serie de ser necesario
ser.flush()
#dar permiso al puerto sudo chmod 666 /dev/ttyUSB0
from threading import Thread  #Crear threads para correr dos cosas simultaneamenteaaaaa
from time import sleep
import math
global lista_a
lista_a = [0,0]
global read_serial
read_serial = ""
global posiciones
posiciones = [0.0, 0.0, 0]
global control 
control = False
r = 3
l = 25
global pos_ant
pos_ant = [0,0,0] #x,y,theta

def calcular_pos(angulos):
    #Siempre uso como posicion anterior cero para  obtener de una vez el delta de posicion
    global pos_ant
    pos_act = [0,0,0] #x,y,theta
    delta_ang = [float(angulos[0]),float(angulos[1])]
    delta_t = float(angulos[2])
    sigmas = [delta_ang[0]/delta_t, delta_ang[1],delta_t]
    velocidades = [r*sigmas[0], r*sigmas[1]]
    v = (velocidades[0]+velocidades[1])/2
    wr = (r*sigmas[0]/l) - (r*sigmas[1]/l) 
    pos_act[0] = pos_ant[0] + v*math.cos(wr**delta_t)*delta_t
    pos_act[1] = pos_ant[1] + v*math.sin(wr**delta_t)*delta_t
    pos_act[2] = pos_ant[2] + wr*delta_t 
    return pos_act


class RobotCmdVelSubscriber(Node):

    def __init__(self):
        super().__init__('nodo_prueba')
        self.subscription = self.create_subscription( Twist,'robot_teclas', self.listener_callback,10)
        self.publisher_ = self.create_publisher( Twist,'posiciones', 10)
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)


    def listener_callback(self, msg):
        #mensaje = repr(self.get_logger().info(f"Received cmdVel: linear_x={msg.linear.x}, angular_z={msg.angular.z}"))aaawwwwsswsssswwwwwwwaaaaqaa
        global lista_a
        global read_serial
        global x
        global y
        global control
        lineal = int(msg.linear.x)
        angular = int(msg.angular.z)
        lista_n = [lineal, angular]
        #print(lista_n)
        entrada = ser.readline().decode('utf-8').rstrip()
        #print("ya entrada")
        if entrada:
            angulos = entrada.split(',')
            print(angulos)
            #posiciones = calcular_pos(angulos)

        var= [1, 5, 50]
        posiciones = calcular_pos(var)
        print(posiciones)

        if(lista_n != lista_a):
            #print(lista_n)
            #print(lista_a)
            #print(f"{lineal},{angular}\n")
            ser.write(f"{lineal},{angular}\n".encode())
            control = True
            #print(read_serial)
            time.sleep(0.1)
        lista_a = lista_n
        

    def timer_callback(self):
        global posiciones
        print("Si")
        msg_angulos = Twist()
        msg_angulos.linear.x = posiciones[0]
        msg_angulos.linear.y = posiciones[1]
        self.publisher_.publish(msg_angulos)







def main(args=None):
    rclpy.init(args=args)
    #t = Thread(target=leer_encoders) #inicia un segundo hilo en el cual va a correr la interfaz
    #t.start() #inicia la interfaz
    robot_cmd_vel_subscriber = RobotCmdVelSubscriber()
    rclpy.spin(robot_cmd_vel_subscriber)
    #t.join()
    rclpy.shutdown()

if __name__ == '__main__':
    main()